============
Version 0.5
============

- Add feature to edit existing notes from within application

============
Version 0.4
============

- Replace GUI version slider with implementation of MPV OSC (lua)

============
Version 0.3
============

- Add About dialog
- Add usage manual

============
Version 0.2
============

- Add movable progress bar.
- Numerous minor GUI changes and bug fixes.

============
Version 0.1
============

- Initial Beta release.