import os
PROJECT_ROOT = os.path.dirname(os.path.dirname(__file__)) + '/'
