============
Version 0.4
============

- Replaced GUI version slider with implementation of MPV OSC (lua)

============
Version 0.3
============

- Added About dialog
- Added usage manual

============
Version 0.2
============

- Addition of a movable progress bar.
- Numerous minor GUI changes and bug fixes.

============
Version 0.1
============

- Initial Beta release.