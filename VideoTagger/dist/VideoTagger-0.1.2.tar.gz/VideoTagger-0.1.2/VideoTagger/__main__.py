#!/usr/bin/env python3
from src import run_gui as run
# dev note: when testing in PyCharm, remove relative "." from src. Add it back to create python package.

if __name__ == '__main__':
    run.Main()